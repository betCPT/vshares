#!/sbin/sh

BOOTPATH="/dev/block/platform/11120000.ufs/by-name/BOOT"

/tmp/busybox dd if=$BOOTPATH of=/tmp/boot.img
mkdir -p /tmp/split_img
cd /tmp/split_img
/tmp/magiskboot unpack -h /tmp/boot.img
rm /tmp/split_img/kernel

MODEL=$(getprop ro.product.name)
CPU=$(cat /tmp/aroma/cpu.prop | cut -d '=' -f2)

echo "MODEL=$MODEL"
echo "CPU=$CPU"

case "$MODEL" in
	*G960* | starlte* | *starlte*)
	  if [ $CPU = 1 ]; then
		/tmp/bspatch /tmp/G965-dtb /tmp/split_img/kernel_dtb /tmp/G960-oc-dtb.patch
		/tmp/bspatch /tmp/G965-zImage /tmp/split_img/kernel /tmp/G960-oc-zImage.patch
	  elif [ $CPU = 3 ]; then
		/tmp/bspatch /tmp/G965-dtb /tmp/split_img/kernel_dtb /tmp/G960-uc-dtb.patch
		/tmp/bspatch /tmp/G965-zImage /tmp/split_img/kernel /tmp/G960-uc-zImage.patch
	  else
		/tmp/bspatch /tmp/G965-dtb /tmp/split_img/kernel_dtb /tmp/G960-dtb.patch
		/tmp/bspatch /tmp/G965-zImage /tmp/split_img/kernel /tmp/G960-zImage.patch
	  fi
	  ;;
	
	*G965* | star2lte* | *star2lte*)
	  if [ $CPU = 1 ]; then
		/tmp/bspatch /tmp/G965-dtb /tmp/split_img/kernel_dtb /tmp/G965-oc-dtb.patch
		/tmp/bspatch /tmp/G965-zImage /tmp/split_img/kernel /tmp/G965-oc-zImage.patch
	  elif [ $CPU = 3 ]; then
		/tmp/bspatch /tmp/G965-dtb /tmp/split_img/kernel_dtb /tmp/G965-uc-dtb.patch
		/tmp/bspatch /tmp/G965-zImage /tmp/split_img/kernel /tmp/G965-uc-zImage.patch
	  else
		cp /tmp/G965-dtb /tmp/split_img/kernel_dtb
		cp /tmp/G965-zImage /tmp/split_img/kernel	
	  fi
	  ;;

	*)
	  echo Installation failed
	  exit
	  ;;
esac

/tmp/magiskboot hexpatch /tmp/split_img/kernel 736B69705F696E697472616D667300 77616E745F696E697472616D667300;

/tmp/magiskboot cpio ramdisk.cpio test;
magisk_patched=$?;
test ! -f .magisk && /tmp/magiskboot cpio /tmp/split_img/ramdisk.cpio "extract .backup/.magisk .magisk";
export $(cat .magisk);
test $((magisk_patched & 8)) -ne 0 && export TWOSTAGEINIT=true;

/tmp/magiskboot dtb /tmp/split_img/kernel_dtb patch;

/tmp/magiskboot repack /tmp/boot.img /tmp/newboot.img

/tmp/busybox dd if=/tmp/newboot.img of=$BOOTPATH

